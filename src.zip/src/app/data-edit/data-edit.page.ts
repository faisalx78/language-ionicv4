import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-edit',
  templateUrl: './data-edit.page.html',
  styleUrls: ['./data-edit.page.scss'],
})
export class DataEditPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
